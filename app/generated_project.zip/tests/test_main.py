import pytest
from app.main import app
@pytest.fixture
def test_app():
    return app
def test_get_users():
    response = test_app().get("/api/users")
    assert response.status_code == 200

def test_get_items():
    response = test_app().get("/api/items")
    assert response.status_code == 200